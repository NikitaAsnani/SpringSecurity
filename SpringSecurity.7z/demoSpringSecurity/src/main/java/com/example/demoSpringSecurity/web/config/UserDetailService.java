package com.example.demoSpringSecurity.web.config;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.example.demoSpringSecurity.web.entity.User;
import com.example.demoSpringSecurity.web.repository.UserRepository;

public class UserDetailService implements UserDetailsService {

	@Autowired
	UserRepository userRepository;
	public UserDetailService(UserRepository userRepository) {
		this.userRepository = userRepository;
	}
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> userOp = userRepository.findByUserName(username);
		userOp.orElseThrow(() -> new UsernameNotFoundException("user name not available"));
		return userOp.map(user -> new org.springframework.security.core.userdetails.User(user.getUserName(),
				user.getPswd(), getAuthorities(user))).get();
			
	}
	private Collection<? extends GrantedAuthority> getAuthorities(User user) {
		return user.getRoles().stream().map(
				role-> new SimpleGrantedAuthority("ROLE_"+role.getRole()))
		.collect(Collectors.toList());
	}

}
