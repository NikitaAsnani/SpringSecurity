package com.example.demoSpringSecurity.web.repository;

import java.io.Serializable;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demoSpringSecurity.web.entity.User;

public interface UserRepository extends JpaRepository<User, Serializable>{

	Optional<User> findByUserName(String userName);
}
