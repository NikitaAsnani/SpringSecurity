package com.example.demoSpringSecurity;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demoSpringSecurity.web.entity.Role;
import com.example.demoSpringSecurity.web.entity.User;
import com.example.demoSpringSecurity.web.repository.UserRepository;

@SpringBootApplication
public class DemoSpringSecurityApplication implements CommandLineRunner{

	@Autowired
	UserRepository userRepository;
	public static void main(String[] args) {
		SpringApplication.run(DemoSpringSecurityApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		userRepository.deleteAll();
		Role role = new Role("ADMIN");
		Set<Role> roles = new HashSet<>();
		roles.add(role);
		roles.add( new Role("USER"));
		User user = new User("nikita","nik",roles);
		userRepository.saveAndFlush(user);
		
		Set<Role> newroles = new HashSet<>();
		newroles.add( new Role("USER"));
	
		User newuser = new User("diksha","dik",newroles);
		userRepository.saveAndFlush(newuser);
	}
	
	
}
